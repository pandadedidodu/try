import { Component, OnInit, ViewChild, ElementRef  } from '@angular/core';
import * as DocumentEditor from '@ckeditor/ckeditor5-build-decoupled-document';
import { ChangeEvent, BlurEvent } from '@ckeditor/ckeditor5-angular/ckeditor.component';
import { ContentService } from '../content.service'; 
import * as ace from 'ace-builds';
import 'ace-builds/src-noconflict/mode-html';
import 'ace-builds/src-noconflict/theme-chrome';
import { CodegenComponentFactoryResolver } from '@angular/core/src/linker/component_factory_resolver';

const THEME = 'ace/theme/chrome'; 
const LANG = 'ace/mode/html';

@Component({
  selector: 'app-edit-page',
  templateUrl: './edit-page.component.html',
  styleUrls: ['./edit-page.component.css']
})
export class EditPageComponent implements OnInit {

  @ViewChild('codeEditor') codeEditorElmRef: ElementRef;
  private codeEditor: ace.Ace.Editor;


  constructor(private sc: ContentService) { }

  content: any;
  active_content: any;

  public Editor = DocumentEditor;
  edit: any;
  model = {
    editorData: '<p>Hello, world!!</p>',

    config: {
      toolbar: ["heading", "|", "fontSize", 
      "fontFamily", "alignment", , "bold", "italic",
      "strikethrough", "underline", "highlight", "blockQuote",  
      "numberedList", "bulletedList","insertTable", "|", "undo", "redo",]
     }
  };

  ngOnInit() {

    const element = this.codeEditorElmRef.nativeElement;
        const editorOptions: Partial<ace.Ace.EditorOptions> = {
            highlightActiveLine: true,
            minLines: 36,
            maxLines: Infinity
        };

        this.codeEditor = ace.edit(element, editorOptions);
        this.codeEditor.setTheme(THEME);
        this.codeEditor.getSession().setMode(LANG);
        this.codeEditor.setShowFoldWidgets(true); // for the scope fold feature

  }

  public setContent(value) {
    if (this.codeEditor) {
        const code = this.codeEditor.setValue(value);
    }
}

public getContent() {
  if (this.codeEditor) {
      const code = this.codeEditor.getValue();
      return code;
  }
}

  onReady(editor){
    editor.ui.getEditableElement().parentElement.insertBefore(
      editor.ui.view.toolbar.element,
      editor.ui.getEditableElement()
    );

    this.sc.pullData('select').subscribe(data => {
      this.content = data;
      this.edit = editor;
      if(this.content[0]){
        this.active_content = this.content[0];
        editor.setData(this.content[0].content);
        //console.log(this.model.editorData);
      }
    });
    
    
  }

  onChangeSource(source){
    console.log(source);
  }

  changePage(i){
    this.active_content = this.content[i];
    this.edit.setData(this.content[i].content);
  }


  editorToSource(editor){
    var temp = editor.getData().split("</p>");
    console.log(temp);
    this.setContent(temp.join("</p>\n"));
  }

  sourceToEditor(){
    this.edit.setData(this.getContent());
  }


  public onChange( { editor }: ChangeEvent ) {
    this.active_content['content'] = this.edit.getData();
    console.log(this.active_content['content']);
    this.editorToSource(editor);
    this.sc.pushData("changeContent", this.active_content);
  }

  public onBlur({ editor } : BlurEvent){
    const data = editor.getData();
   //console.log(Array.from(editor.ui.componentFactory.names()));
    console.log( data );
  }

}
