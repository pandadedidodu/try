import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})


export class ContentService {
 
  private apiLink = 'http://localhost/student_manual/';  // URL to web api
 

  constructor(private http: HttpClient) { }

  pullData(vUrl,data?: string){
    if(data){
      return this.http.get(this.apiLink + vUrl +'.php?'+ data);
    }
    return this.http.get(this.apiLink + vUrl +'.php');
  }

  pushData(vUrl, payload){
    return this.http.post(this.apiLink + vUrl + '.php', payload);
  }

}
